/*
** Função : função que classifica os elementos de um vetor em ordem crescente
** Autor : Iury Mendonça Freire de França
** Data : 05/06/2024
** Observações:
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//trocar de lugar
void trocar(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

//classificação por seleção
void selectionSort(int vetor[], int n) {
    for (int i = 0; i < n - 1; i++) {
        
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (vetor[j] < vetor[minIndex]) {
                minIndex = j;
            }
        }
        
        trocar(&vetor[minIndex], &vetor[i]);
    }
}

//imprimir o vetor
void imprimirVetor(int vetor[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

int main() {
    int n = 10; 
    int vetor[n];

   
    srand(time(NULL));

    // Gerar valores aleatórios para o vetor
    for (int i = 0; i < n; i++) {
        vetor[i] = rand() % 100;
    }

    printf("Vetor original:\n");
    imprimirVetor(vetor, n);

    // Classifica o vetor
    selectionSort(vetor, n);

    printf("Vetor classificado:\n");
    imprimirVetor(vetor, n);

    return 0;
}
