/*
** Função : função que classifica os elementos de um vetor em ordem crescente
usando o algoritmo “quicksort”
** Autor : Iury Mendonça Freire de França
** Data : 05/06/2024
** Observações:
*/

#include <stdio.h>

//Rrocar dois elementos de lugar
void trocar(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Quicksort
int particao(int vetor[], int baixo, int alto) {
    int pivo = vetor[(baixo + alto) / 2];
    int i = baixo;
    int j = alto;

    while (i <= j) {
        while (vetor[i] < pivo) {
            i++;
        }
        while (vetor[j] > pivo) {
            j--;
        }
        if (i <= j) {
            trocar(&vetor[i], &vetor[j]);
            i++;
            j--;
        }
    }
    return i;
}

void quicksort(int vetor[], int baixo, int alto) {
    if (baixo < alto) {
        int indiceParticao = particao(vetor, baixo, alto);
        quicksort(vetor, baixo, indiceParticao - 1);
        quicksort(vetor, indiceParticao, alto);
    }
}

// Imprimir vetor
void imprimirVetor(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}


int main() {
    int vetor[] = {34, 7, 23, 32, 5, 62, 32, 25};
    int tamanho = sizeof(vetor) / sizeof(vetor[0]);

    printf("Vetor original:\n");
    imprimirVetor(vetor, tamanho);

    quicksort(vetor, 0, tamanho - 1);

    printf("Vetor ordenado:\n");
    imprimirVetor(vetor, tamanho);

    return 0;
}
