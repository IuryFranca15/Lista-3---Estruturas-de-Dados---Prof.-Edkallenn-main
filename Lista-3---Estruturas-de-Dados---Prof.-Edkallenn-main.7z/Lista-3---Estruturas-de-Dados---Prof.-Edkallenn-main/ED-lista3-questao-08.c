/*
** Função : Crie um novo TAD (Tipo Abstrato de Dado) de arquivo único chamado Complexo para
realizar aritmética com números complexos. Utilize variáveis double para representar os
campos deste tipo. Implemente funções para as seguintes operações: criar e destruir um
número complexo; ler um número complexo, somar dois números complexos, subtrair dois
números complexos, multiplicar dois números complexos, dividir dois números complexos,
mostrar um número complexo na forma (a,b) onde a é a parte real e b, a parte imaginária.
** Autor : Iury Mendonça Freire de França
** Data : 05/06/2024
** Observações:
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct {
    double real;
    double imaginario;
} Complexo;

// Criar um número complexo
Complexo* criarComplexo(double real, double imaginario) {
    Complexo* novoComplexo = (Complexo*)malloc(sizeof(Complexo));
    if (novoComplexo == NULL) {
        printf("Erro ao alocar memória!\n");
        exit(1);
    }
    novoComplexo->real = real;
    novoComplexo->imaginario = imaginario;
    return novoComplexo;
}

// Destruir um número complexo
void destruirComplexo(Complexo* complexo) {
    free(complexo);
}

// Ler um número complexo
Complexo* lerComplexo() {
    double real, imaginario;
    printf("Digite a parte real: ");
    scanf("%lf", &real);
    printf("Digite a parte imaginaria: ");
    scanf("%lf", &imaginario);
    return criarComplexo(real, imaginario);
}

//Somar dois números complexos
Complexo* somarComplexos(Complexo* c1, Complexo* c2) {
    return criarComplexo(c1->real + c2->real, c1->imaginario + c2->imaginario);
}

//Subtrair dois números complexos
Complexo* subtrairComplexos(Complexo* c1, Complexo* c2) {
    return criarComplexo(c1->real - c2->real, c1->imaginario - c2->imaginario);
}

// Mltiplicar dois números complexos
Complexo* multiplicarComplexos(Complexo* c1, Complexo* c2) {
    double real = c1->real * c2->real - c1->imaginario * c2->imaginario;
    double imaginario = c1->real * c2->imaginario + c1->imaginario * c2->real;
    return criarComplexo(real, imaginario);
}

// Dividir dois números complexos
Complexo* dividirComplexos(Complexo* c1, Complexo* c2) {
    double denominador = c2->real * c2->real + c2->imaginario * c2->imaginario;
    if (denominador == 0) {
        printf("Erro: divisão por zero!\n");
        exit(1);
    }
    double real = (c1->real * c2->real + c1->imaginario * c2->imaginario) / denominador;
    double imaginario = (c1->imaginario * c2->real - c1->real * c2->imaginario) / denominador;
    return criarComplexo(real, imaginario);
}

// Mostrar um número complexo
void mostrarComplexo(Complexo* complexo) {
    printf("(%.2lf, %.2lf)\n", complexo->real, complexo->imaginario);
}

//Testar o TAD Complexo
int main() {
    Complexo* c1 = lerComplexo();
    Complexo* c2 = lerComplexo();

    printf("Primeiro número complexo: ");
    mostrarComplexo(c1);
    printf("Segundo número complexo: ");
    mostrarComplexo(c2);

    Complexo* soma = somarComplexos(c1, c2);
    printf("Soma: ");
    mostrarComplexo(soma);

    Complexo* subtracao = subtrairComplexos(c1, c2);
    printf("Subtracao: ");
    mostrarComplexo(subtracao);

    Complexo* multiplicacao = multiplicarComplexos(c1, c2);
    printf("Multiplicacao: ");
    mostrarComplexo(multiplicacao);

    Complexo* divisao = dividirComplexos(c1, c2);
    printf("Divisao: ");
    mostrarComplexo(divisao);

    destruirComplexo(c1);
    destruirComplexo(c2);
    destruirComplexo(soma);
    destruirComplexo(subtracao);
    destruirComplexo(multiplicacao);
    destruirComplexo(divisao);

    return 0;
}
