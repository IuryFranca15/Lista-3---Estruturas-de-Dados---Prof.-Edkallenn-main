/*
** Função : Defina uma estrutura em C com o nome de aeroporto, que tenha os campos apropriados
para guardar todas as informações descritas anteriormente. Defina também um novo tipo
de dados com o nome de Aeroporto, correspondendo a essa estrutura. Defina um vetor de
Aeroportos (usando alocação dinâmica para a quantidade de aeroportos) para armazenar
todos os aeroportos que a empresa aérea trabalha. Implementar rotinas para ler, escrever e
excluir registros deste tipo.
** Autor : Iury Mendonça Freire de França
** Data : 05/06/2024
** Observações:
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definição do struct Aeroporto
typedef struct {
    char sigla[4];
    char cidade[51];
    char pais[31];
    float taxa;
    int capacidade;
} Aeroporto;

// Ler os dados de um aeroporto
void lerAeroporto(Aeroporto *aeroporto) {
    printf("Digite a sigla: ");
    fgets(aeroporto->sigla, 4, stdin);
    aeroporto->sigla[strcspn(aeroporto->sigla, "\n")] = 0;

    printf("Digite a cidade: ");
    fgets(aeroporto->cidade, 51, stdin);
    aeroporto->cidade[strcspn(aeroporto->cidade, "\n")] = 0;
    printf("Digite o país: ");
    fgets(aeroporto->pais, 31, stdin);
    aeroporto->pais[strcspn(aeroporto->pais, "\n")] = 0;

    printf("Digite a taxa: ");
    scanf("%f", &aeroporto->taxa);
    getchar();

    printf("Digite a capacidade: ");
    scanf("%d", &aeroporto->capacidade);
    getchar();
}

// Exibir os dados de um aeroporto
void escreverAeroporto(Aeroporto *aeroporto) {
    printf("Sigla: %s\n", aeroporto->sigla);
    printf("Cidade: %s\n", aeroporto->cidade);
    printf("País: %s\n", aeroporto->pais);
    printf("Taxa: %.2f\n", aeroporto->taxa);
    printf("Capacidade: %d\n", aeroporto->capacidade);
}

//Excluir um aeroporto (definido por index)
void excluirAeroporto(Aeroporto **aeroportos, int *total, int index) {
    if (index < 0 || index >= *total) {
        printf("Índice inválido!\n");
        return;
    }

    free(aeroportos[index]);
    for (int i = index; i < *total - 1; i++) {
        aeroportos[i] = aeroportos[i + 1];
    }

    (*total)--;
    aeroportos = realloc(aeroportos, (*total) * sizeof(Aeroporto *));
    if (*total > 0 && aeroportos == NULL) {
        printf("Erro ao realocar memória!\n");
        exit(1);
    }
}

int main() {
    Aeroporto **aeroportos = NULL;
    int total = 0;
    int opcao;
    int index;

    do {
        printf("Menu:\n");
        printf("1. Adicionar Aeroporto\n");
        printf("2. Listar Aeroportos\n");
        printf("3. Excluir Aeroporto\n");
        printf("0. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);
        getchar();

        switch (opcao) {
            case 1:
                aeroportos = realloc(aeroportos, (total + 1) * sizeof(Aeroporto *));
                if (aeroportos == NULL) {
                    printf("Erro ao alocar memória!\n");
                    exit(1);
                }
                aeroportos[total] = malloc(sizeof(Aeroporto));
                if (aeroportos[total] == NULL) {
                    printf("Erro ao alocar memória!\n");
                    exit(1);
                }
                lerAeroporto(aeroportos[total]);
                total++;
                break;
            case 2:
                for (int i = 0; i < total; i++) {
                    printf("Aeroporto %d:\n", i + 1);
                    escreverAeroporto(aeroportos[i]);
                    printf("\n");
                }
                break;
            case 3:
                printf("Digite o índice do aeroporto a se
