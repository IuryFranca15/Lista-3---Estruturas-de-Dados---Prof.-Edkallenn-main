/*
** Função : Crie uma função para ordenar elementos de um vetor (pode ser de inteiros ou reais)
usando o "método BubbleSort" (ordenação Bolha). Em seguida realize a CONTAGEM 
do número de if's realizados e a quantidade de trocas realizadas. Mostre, ao final, após o vetor estar ordenado, 
a quantidade de if's e de trocas realizadas. Use a função em um 
f(x) = 0 [a, b] f′(x) f′′(x) x0 a b f′(x) f′′(x) xk+1 = xk − ff′((xxkk)) 
x0 f′(xk) f(x) f(x) = x2 − n f′(x) = 2x n f(x) = x2 − n f′(x) = 2x nprograma 
que solicita a quantidade de elementos do vetor para o usuário e preenche 
este vetor com valores aleatórios.
** Autor : Iury Mendonça Freire de França
** Data : 05/06/2024
** Observações:
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Ordenar um vetor usando o método BubbleSort
void bubbleSort(int vetor[], int tamanho, int *contagemIfs, int *contagemTrocas) {
    int i, j;
    *contagemIfs = 0;
    *contagemTrocas = 0;
    for (i = 0; i < tamanho - 1; i++) {
        for (j = 0; j < tamanho - i - 1; j++) {
            (*contagemIfs)++;
            if (vetor[j] > vetor[j + 1]) {
                int temp = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = temp;
                (*contagemTrocas)++;
            }
        }
    }
}

// Imprimir o vetor
void imprimirVetor(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

int main() {
    int tamanho;

    printf("Digite a quantidade de elementos do vetor: ");
    scanf("%d", &tamanho);

    int *vetor = (int *)malloc(tamanho * sizeof(int));
    if (vetor == NULL) {
        printf("Erro ao alocar memória!\n");
        return 1;
    }

    // Gerador de números aleatórios
    srand(time(NULL));

    //Vetor com valores aleatórios
    for (int i = 0; i < tamanho; i++) {
        vetor[i] = rand() % 100;
    }

    printf("Vetor original:\n");
    imprimirVetor(vetor, tamanho);

    int contagemIfs, contagemTrocas;
    bubbleSort(vetor, tamanho, &contagemIfs, &contagemTrocas);

    printf("Vetor ordenado:\n");
    imprimirVetor(vetor, tamanho);

    printf("Número de if's realizados: %d\n", contagemIfs);
    printf("Número de trocas realizadas: %d\n", contagemTrocas);

    free(vetor);

    return 0;
}
