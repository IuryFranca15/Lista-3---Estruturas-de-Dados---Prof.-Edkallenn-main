/*
** Função : Defina um registro (estrutura - struct) empregado para armazenar os dados (nome, data de
nascimento, RG, data de admissão e salário)de um empregado de uma empresa. 
** Autor : Iury Mendonça Freire de França
** Data : 05/06/2024
** Observações:
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definição do struct Empregado
typedef struct {
    char nome[100];
    char data_nascimento[11];
    char RG[15];
    char data_admissao[11]; 
    float salario;
} Empregado;

void lerEmpregado(Empregado *emp) {
    printf("Digite o nome: ");
    fgets(emp->nome, 100, stdin);
    emp->nome[strcspn(emp->nome, "\n")] = 0;

    printf("Digite a data de nascimento (DD/MM/AAAA): ");
    fgets(emp->data_nascimento, 11, stdin);
    emp->data_nascimento[strcspn(emp->data_nascimento, "\n")] = 0;

    printf("Digite o RG: ");
    fgets(emp->RG, 15, stdin);
    emp->RG[strcspn(emp->RG, "\n")] = 0;

    printf("Digite a data de admissão (DD/MM/AAAA): ");
    fgets(emp->data_admissao, 11, stdin);
    emp->data_admissao[strcspn(emp->data_admissao, "\n")] = 0;

    printf("Digite o salário: ");
    scanf("%f", &emp->salario);
    getchar();
}


void escreverEmpregado(Empregado emp) {
    printf("Nome: %s\n", emp.nome);
    printf("Data de Nascimento: %s\n", emp.data_nascimento);
    printf("RG: %s\n", emp.RG);
    printf("Data de Admissão: %s\n", emp.data_admissao);
    printf("Salário: %.2f\n", emp.salario);
}


void excluirEmpregado(Empregado *empregados, int *total, int index) {
    if (index < 0 || index >= *total) {
        printf("Índice inválido!\n");
        return;
    }

    for (int i = index; i < *total - 1; i++) {
        empregados[i] = empregados[i + 1];
    }

    (*total)--;
    empregados = realloc(empregados, (*total) * sizeof(Empregado));
    if (*total > 0 && empregados == NULL) {
        printf("Erro ao realocar memória!\n");
        exit(1);
    }
}

int main() {
    Empregado *empregados = NULL;
    int total = 0;
    int opcao;
    int index;

    do {
        printf("Menu:\n");
        printf("1. Adicionar Empregado\n");
        printf("2. Listar Empregados\n");
        printf("3. Excluir Empregado\n");
        printf("0. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);
        getchar(); 

        switch (opcao) {
            case 1:
                empregados = realloc(empregados, (total + 1) * sizeof(Empregado));
                if (empregados == NULL) {
                    printf("Erro ao alocar memória!\n");
                    exit(1);
                }
                lerEmpregado(&empregados[total]);
                total++;
                break;
            case 2:
                for (int i = 0; i < total; i++) {
                    printf("Empregado %d:\n", i + 1);
                    escreverEmpregado(empregados[i]);
                    printf("\n");
                }
                break;
            case 3:
                printf("Digite o índice do empregado a ser excluído (1 a %d): ", total);
                scanf("%d", &index);
                getchar();
                excluirEmpregado(empregados, &total, index - 1);
                break;
            case 0:
                break;
            default:
                printf("Opção inválida!\n");
        }
    } while (opcao != 0);

    free(empregados);
    return 0;
}
