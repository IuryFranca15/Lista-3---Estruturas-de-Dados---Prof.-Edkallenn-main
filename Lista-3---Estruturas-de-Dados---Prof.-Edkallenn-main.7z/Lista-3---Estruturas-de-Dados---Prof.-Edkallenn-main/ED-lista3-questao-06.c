/*
** Função : Pesquise em livros ou na Internet como funciona o método de Newton,
crie um algoritmo e aplique-o em uma função para calcular a raiz quadrada de um número
n com aproximação de 0.0001.
** Autor : Iury Mendonça Freire de França
** Data : 05/06/2024
** Observações:
*/

#include <stdio.h>
#include <math.h>

// Calcular a raiz quadrada usando o método de Newton-Raphson
double raizQuadrada(double n) {
    double x = n;
    double epsilon = 0.0001;
    double raiz;

    while (1) {
        raiz = 0.5 * (x + (n / x));
        if (fabs(raiz - x) < epsilon) {
            break;
        }
        x = raiz;
    }

    return raiz;
}

int main() {
    double n;

    printf("Digite um número para calcular a raiz quadrada: ");
    scanf("%lf", &n);

    if (n < 0) {
        printf("Número inválido! Digite um número não-negativo.\n");
        return 1;
    }

    // Raiz quadrada usando o método de Newton-Raphson
    double resultado = raizQuadrada(n);

    printf("A raiz quadrada de %.4f é aproximadamente %.4f\n", n, resultado);

    return 0;
}
